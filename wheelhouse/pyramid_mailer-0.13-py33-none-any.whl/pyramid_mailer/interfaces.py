from zope.interface import Interface

class IMailer(Interface):
    pass
    
