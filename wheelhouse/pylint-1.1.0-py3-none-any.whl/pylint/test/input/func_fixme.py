"""docstring"""

__revision__ = ''

# FIXME: beep

def function():
    '''XXX:bop'''

