
import string
print(string)
