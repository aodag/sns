"""a package with absolute import activated
"""



