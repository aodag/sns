# Copyright (c) 2008 Simplistix Ltd
# See license.txt for license details.
import warnings
warnings.simplefilter('default', ImportWarning)
