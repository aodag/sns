print('yo')
