#!python
# EASY-INSTALL-ENTRY-SCRIPT: 'Babel==1.3','console_scripts','pybabel'
__requires__ = 'Babel==1.3'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('Babel==1.3', 'console_scripts', 'pybabel')()
    )
