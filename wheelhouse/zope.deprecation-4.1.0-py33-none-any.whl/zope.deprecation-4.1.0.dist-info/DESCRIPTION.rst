``zope.deprecation`` README
===========================

This package provides a simple function called ``deprecated(names, reason)``
to mark deprecated modules, classes, functions, methods and properties.

Please see http://docs.zope.org/zope.deprecation/ for the documentation.



``zope.deprecation`` Changelog
==============================

4.1.0 (2013-12-20)
------------------

- Added a ``Suppressor`` context manager, allowing scoped suppression of
  deprecation warnings.

- Updated ``boostrap.py`` to version 2.2.

4.0.2 (2012-12-31)
------------------

- Fleshed out PyPI Trove classifiers.

4.0.1 (2012-11-21)
------------------

- Added support for Python 3.3.

4.0.0 (2012-05-16)
------------------

- Automated build of Sphinx HTML docs and running doctest snippets via tox.

- Added Sphinx documentation:

  - API docs moved from package-data README into ``docs/api.rst``.

  - Snippets can be tested by running 'make doctest'.

- Updated support for continuous integration using ``tox`` and ``jenkins``.

- 100% unit test coverage.

- Added ``setup.py dev`` alias (runs ``setup.py develop`` plus installs
  ``nose`` and ``coverage``).

- Added ``setup.py docs`` alias (installs ``Sphinx`` and dependencies).

- Removed spurious dependency on ``zope.testing``.

- Dropped explicit support for Python 2.4 / 2.5 / 3.1.


3.5.1 (2012-03-15)
------------------

- Revert a move of `README.txt` to unbreak ``zope.app.apidoc``.


3.5.0 (2011-09-05)
------------------

- Replaced doctesting with unit testing.

- Python 3 compatibility.


3.4.1 (2011-06-07)
------------------

- Removed import cycle for ``__show__`` by defining it in the
  ``zope.deprecation.deprecation`` module.

- Added support to bootstrap on Jython.

- Fix ``zope.deprecation.warn()`` to make the signature identical to
  ``warnings.warn()`` and to check for .pyc and .pyo files.


3.4.0 (2007-07-19)
------------------

- Release 3.4 final, corresponding to Zope 3.4.


3.3.0 (2007-02-18)
------------------

- Corresponds to the version of the ``zope.deprecation`` package shipped as
  part of the Zope 3.3.0 release.


